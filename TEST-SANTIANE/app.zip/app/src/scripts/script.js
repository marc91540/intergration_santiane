// CALLBACK
$(document).ready(function(){
  // alert('bruh');
})

// AJAX
$(document).ready(function(){
  var articles = $('article');

  var status = $('.status').val();
  var active = $('.active').val();
  var location = $('.location').val();
  var leagues = $('.leagues').val();


  
    $.ajax({
      url: "http://spider.in.santiane.fr/api/v1/leagues/agents?fields={}", 
      type: 'get',
      dataType : 'html', // On désire recevoir du HTML

      success: function(result){
        console.log(result);

    }});
});

